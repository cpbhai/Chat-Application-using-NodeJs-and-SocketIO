const socket = io('http://localhost:8000')
const form = document.getElementById('sendContainer')
const msgInp = document.getElementById('messageInp')
const messageContainer = document.querySelector('.container')

var audio=new Audio('ting.mp3')

const append = (message, position) => {
    const messageElement = document.createElement('div')
    messageElement.innerText = message
    messageElement.classList.add('message')
    messageElement.classList.add(position);
    messageContainer.append(messageElement)
    var element = document.getElementById("container");
    element.scrollTop = element.scrollHeight;
}

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const msg = messageInp.value
    append(`Me: ${msg}`, 'right')
    socket.emit('send', msg)
    messageInp.value = ''
})

const name = prompt('Enter Your Name to Join')
socket.emit('new-user-joined', name)

socket.on('user-joined', name => {
    append(`${name} joined the chat`, 'right')
})
socket.on('receive', data => {
    audio.play();
    append(`${data.name}: ${data.message}`, 'left')//received from server(index.js)
})
socket.on('left', user => {
    append(`${user} Left the chat`, 'left')
})